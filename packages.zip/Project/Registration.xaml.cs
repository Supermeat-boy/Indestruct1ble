﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public MainWindow mWindow;
        public indestructableDataSet indestructable = new indestructableDataSet();

        public Registration(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mWindow = mainWindow;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (texBox1.Text != null && textBox2.Password != null && textBox3.Password != null)
            {
                if (textBox2.Password == textBox3.Password)
                {
                    AddUser usr = new AddUser
                    {
                        login = texBox1.Text,
                        password = textBox2.Password,
                        role = comboBox1.SelectedIndex +3,
                        nameUser = texBox4.Text
                    };
                    indestructable.user.InsertOnSubmit(usr);
                    try
                    {
                        indestructable.SubmitChanges();
                    }
                    catch (Exception x)
                    {
                        MessageBox.Show(x.Message, "Mistake or error? i dont know(err)");
                    }
                }
            }
        }
    }
}
