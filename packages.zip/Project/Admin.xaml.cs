﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Page
    {
        public MainWindow mWindow;
        public indestructableDataSet ind = new indestructableDataSet();
        public Admin(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mWindow = mainWindow;
            dataGrid1.ItemsSource = ind.user;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = ind.user;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Registration register = new Registration(mWindow);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
