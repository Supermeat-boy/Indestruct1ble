﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для User.xaml
    /// </summary>
    public partial class User : Page
    {
        public MainWindow mWindow;
        public indestructableDataSet ind = new indestructableDataSet();
        private int tableIndex;
        public User(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mWindow = mainWindow;
            dataGrid1.ItemsSource = ind.product;
            tableIndex = 2;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = ind.furniture;
            tableIndex = 0;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = ind.cloth;
            tableIndex = 1;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = ind.product;
            tableIndex = 2;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            switch (tableIndex)
            {
                case 0:
                    dataGrid1.ItemsSource = ind.furniture;
                    break;
                case 1:
                    dataGrid1.ItemsSource = ind.cloth;
                    break;
                case 2:
                    dataGrid1.ItemsSource = ind.product;
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }
    }
}
