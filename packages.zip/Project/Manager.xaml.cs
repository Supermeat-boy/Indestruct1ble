﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Manager.xaml
    /// </summary>
    public partial class Manager : Page
    {
        public MainWindow mWindow;
        public indestructableDataSet indestructable = new indestructableDataSet();
        public Manager(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mWindow = mainWindow;
            dataGrid1.ItemsSource = indestructable.product;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            dataGrid1.ItemsSource = indestructable.product;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            mWindow.OpenPage(MainWindow.Pages.Login);
        }

         
    }
}
